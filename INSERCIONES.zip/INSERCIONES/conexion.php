<?php

$host = "localhost";
$user = "root";
$clave = "";
$bd = "prueba2_nicolas_ramirez_sandoval";

$conn = mysqli_connect($host, $user, $clave, $bd);

?>